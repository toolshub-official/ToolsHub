const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const path = require('path');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: 'secret-key', resave: false, saveUninitialized: false }));
app.use(express.static('public'));

mongoose.connect('mongodb://localhost:27017/multitools', { useNewUrlParser: true, useUnifiedTopology: true });

const User = mongoose.model('User', new mongoose.Schema({
  email: String,
  password: String,
  subscription: { type: Boolean, default: false }
}));

app.post('/signup', async (req, res) => {
  const hashedPassword = await bcrypt.hash(req.body.password, 10);
  await User.create({ email: req.body.email, password: hashedPassword });
  res.redirect('/login.html');
});

app.post('/login', async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (user && await bcrypt.compare(req.body.password, user.password)) {
    req.session.user = user;
    res.redirect('/dashboard.html');
  } else {
    res.send('Login failed. <a href="/login.html">Try again</a>');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login.html');
});

app.post('/confirm-subscription', async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (user) {
    user.subscription = true;
    await user.save();
    res.send('Subscription activated. <a href="/dashboard.html">Go to Dashboard</a>');
  } else {
    res.send('User not found.');
  }
});

function requireSubscription(req, res, next) {
  if (req.session.user && req.session.user.subscription) {
    next();
  } else {
    res.redirect('/subscribe.html');
  }
}

app.get('/tools/pdf-compressor.html', requireSubscription, (req, res) => {
  res.sendFile(path.join(__dirname, 'public/tools/pdf-compressor.html'));
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));